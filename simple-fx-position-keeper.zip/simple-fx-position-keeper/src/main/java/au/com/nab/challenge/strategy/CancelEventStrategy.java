package au.com.nab.challenge.strategy;

import au.com.nab.challenge.Position;
import au.com.nab.core.CancelTradeEvent;
import au.com.nab.core.Event;

import java.util.Map;

public class CancelEventStrategy implements Strategy {

    @Override
    public Map<Long, Position> doOperation(Event event, Map<Long, Position> positionMap) {
        CancelTradeEvent cancelTradeEvent = (CancelTradeEvent) event;

        if (positionMap.isEmpty() || positionMap.get(cancelTradeEvent.getTradeId()) == null)
            positionMap.put(cancelTradeEvent.getTradeId(), new Position(cancelTradeEvent.getTradeId(), Boolean.FALSE));
        else {
            Position temp = positionMap.get(cancelTradeEvent.getTradeId());
            temp.setStatus(Boolean.FALSE);
            positionMap.put(cancelTradeEvent.getTradeId(), temp);
        }

        return positionMap;
    }
}
