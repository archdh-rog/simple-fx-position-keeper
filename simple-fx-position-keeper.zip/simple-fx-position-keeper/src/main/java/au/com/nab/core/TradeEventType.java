package au.com.nab.core;

public enum TradeEventType {
    NEW, AMEND;
}
