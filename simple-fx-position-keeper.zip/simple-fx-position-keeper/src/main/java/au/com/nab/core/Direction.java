package au.com.nab.core;

public enum Direction {
    BUY, SELL, UNDEFINED;
}
