package au.com.nab.core;

public interface Event {
}
