package au.com.nab.challenge.strategy;

import au.com.nab.challenge.Position;
import au.com.nab.core.Direction;
import au.com.nab.core.Event;
import au.com.nab.core.TradeEvent;
import au.com.nab.core.TradeEventType;

import java.text.DecimalFormat;
import java.util.Map;

public class TradeEventStrategy implements Strategy {

    private static DecimalFormat df = new DecimalFormat("0.00");

    @Override
    public Map<Long, Position> doOperation(Event event, Map<Long, Position> positionMap) {
        TradeEvent tradeEvent = (TradeEvent) event;

        if (positionMap.isEmpty() || positionMap.get(tradeEvent.getTradeId()) == null)
            positionMap.put(tradeEvent.getTradeId(), new Position(tradeEvent.getTradeId(), tradeEvent.getCurrencyPair()));

        Position position = positionMap.get(tradeEvent.getTradeId());

        if (position.isStatus()) {
            if (TradeEventType.NEW.equals(tradeEvent.getTradeEventType()) && !position.getTradeEventType().equalsIgnoreCase(TradeEventType.AMEND.toString()))
                position = calculatePosition(tradeEvent, position);
            else if (TradeEventType.AMEND.equals(tradeEvent.getTradeEventType()) && tradeEvent.getVersion() > position.getVersion())
                position = calculatePosition(tradeEvent, position);

            positionMap.put(tradeEvent.getTradeId(), position);
        }

        return positionMap;
    }

    private Position calculatePosition(TradeEvent tradeEvent, Position position) {
        double baseCurrency = 0.00;
        double termCurrency = 0.00;

        if (Direction.BUY.equals(tradeEvent.getDirection())) {
            baseCurrency = position.getAmountBaseCurrency() + tradeEvent.getAmount();
            termCurrency = baseCurrency * tradeEvent.getFxRate();
            termCurrency = position.getAmountTermCurrency() - termCurrency;

        } else if (Direction.SELL.equals(tradeEvent.getDirection())) {
            baseCurrency = position.getAmountBaseCurrency() - tradeEvent.getAmount();
            termCurrency = baseCurrency * tradeEvent.getFxRate();
            termCurrency = position.getAmountTermCurrency() + termCurrency;

        }

        position.setMarketRate(Math.abs(termCurrency / baseCurrency))
                .setAmountBaseCurrency(Math.round(baseCurrency * 100) / 100)
                .setAmountTermCurrency(Math.round(termCurrency * 100) /100)
                .setTradeEventType(tradeEvent.getTradeEventType().name())
                .setVersion(tradeEvent.getVersion());



        return position;
    }
}
