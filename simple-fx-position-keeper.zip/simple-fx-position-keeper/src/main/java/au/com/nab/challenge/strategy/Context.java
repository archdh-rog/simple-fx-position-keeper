package au.com.nab.challenge.strategy;

import au.com.nab.challenge.Position;
import au.com.nab.core.CancelTradeEvent;
import au.com.nab.core.Event;
import au.com.nab.core.FxRate;
import au.com.nab.core.TradeEvent;

import java.util.Map;

public class Context {

    private Strategy strategy;
    private Event event;

    public Context(Event event) {
        this.event = event;

        if (event instanceof TradeEvent)
            this.strategy = new TradeEventStrategy();
        else if (event instanceof CancelTradeEvent)
            this.strategy = new CancelEventStrategy();
        else if (event instanceof FxRate)
            this.strategy = new FxRateStrategy();
    }

    public Map<Long, Position> executeStrategy(Map<Long, Position> positionMap) {
        return strategy.doOperation(event, positionMap);
    }
}
