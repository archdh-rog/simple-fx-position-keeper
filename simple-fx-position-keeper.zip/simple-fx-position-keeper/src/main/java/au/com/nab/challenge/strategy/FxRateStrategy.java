package au.com.nab.challenge.strategy;

import au.com.nab.challenge.Position;
import au.com.nab.core.Event;
import au.com.nab.core.FxRate;

import java.util.Map;

public class FxRateStrategy implements Strategy {

    @Override
    public Map<Long, Position> doOperation(Event event, Map<Long, Position> positionMap) {
        FxRate fxRate = (FxRate) event;

        positionMap.forEach((tradeId , pos) -> {
            if (fxRate.getCurrencyPair().equalsIgnoreCase(pos.getCurrencyPair())) {
                double newTermCurrency = pos.getAmountBaseCurrency() * fxRate.getRate();
                pos.setAmountTermCurrency(newTermCurrency)
                        .setMarketRate(fxRate.getRate());

                positionMap.put(pos.getTradeId(), pos);
            }
        });

        return positionMap;
    }
}
