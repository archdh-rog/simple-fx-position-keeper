package au.com.nab.challenge;

import au.com.nab.core.AbstractTradeEvent;
import au.com.nab.core.TradeEventType;

import java.util.Objects;

public class Position extends AbstractTradeEvent {
    private String currencyPair;
    private double amountBaseCurrency;
    private double amountTermCurrency;
    private double marketRate;
    private boolean status;
    private int version;
    private String tradeEventType;

    public Position(long tradeId, boolean status) {
        super(tradeId);
        this.status = status;
    }

    public Position(long tradeId, String currencyPair) {
        super(tradeId);
        this.currencyPair = currencyPair;
        this.amountBaseCurrency = 0.00;
        this.amountTermCurrency = 0.00;
        this.status = true;
        this.tradeEventType = TradeEventType.NEW.name();
        this.version = -1;
    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public double getAmountBaseCurrency() {
        return amountBaseCurrency;
    }

    public Position setAmountBaseCurrency(double amountBaseCurrency) {
        this.amountBaseCurrency = amountBaseCurrency;
        return this;
    }

    public double getAmountTermCurrency() {
        return amountTermCurrency;
    }

    public Position setAmountTermCurrency(double amountTermCurrency) {
        this.amountTermCurrency = amountTermCurrency;
        return this;
    }

    public double getMarketRate() {
        return marketRate;
    }

    public Position setMarketRate(double marketRate) {
        this.marketRate = marketRate;
        return this;
    }

    public boolean isStatus() {
        return status;
    }

    public Position setStatus(boolean status) {
        this.status = status;
        return this;
    }

    public int getVersion() {
        return version;
    }

    public Position setVersion(int version) {
        this.version = version;
        return this;
    }

    public String getTradeEventType() {
        return tradeEventType;
    }

    public Position setTradeEventType(String tradeEventType) {
        this.tradeEventType = tradeEventType;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Position position = (Position) o;
        return Double.compare(position.amountBaseCurrency, amountBaseCurrency) == 0 &&
                Double.compare(position.amountTermCurrency, amountTermCurrency) == 0 &&
                Double.compare(position.marketRate, marketRate) == 0 &&
                status == position.status &&
                version == position.version &&
                Objects.equals(currencyPair, position.currencyPair) &&
                Objects.equals(tradeEventType, position.tradeEventType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), currencyPair, amountBaseCurrency, amountTermCurrency, marketRate, status, version, tradeEventType);
    }

    @Override
    public String toString() {
        return "Position{" +
                "currencyPair='" + currencyPair + '\'' +
                ", amountBaseCurrency=" + amountBaseCurrency +
                ", amountTermCurrency=" + amountTermCurrency +
                ", marketRate=" + marketRate +
                ", status=" + status +
                ", version=" + version +
                ", tradeEventType='" + tradeEventType + '\'' +
                '}';
    }
}
