package au.com.nab.challenge;

import au.com.nab.challenge.strategy.Context;
import au.com.nab.core.*;
import au.com.nab.testingUtils.EventReader;
import au.com.nab.testingUtils.TradeEventReceiver;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

public class PositionKeeperImpl implements PositionKeeper {

    private Map<Long, Position> positionMap = new ConcurrentHashMap<>();
    ReentrantLock rel = new ReentrantLock();

    @Override
    public void processEvent(Event event) {
        //Your implementation
        Context context = new Context(event);
        positionMap = context.executeStrategy(positionMap);
    }

    @Override
    public String printPositions() {
        //Your implementation
        StringBuilder builder = new StringBuilder();
        builder.append("CurrencyPair")
                .append(", AmountBaseCurrency")
                .append(", AmountTermCurrency")
                .append(", MarketRate")
                .append("\n");
        positionMap.forEach((k,position) -> {
            if (position.isStatus()) {
                builder.append(position.getCurrencyPair()).append(", ")
                        .append(position.getAmountBaseCurrency()).append(", ")
                        .append(position.getAmountTermCurrency()).append(", ")
                        .append(position.getMarketRate())
                        .append("\n");
            }
        });
        return builder.toString();
    }
}
