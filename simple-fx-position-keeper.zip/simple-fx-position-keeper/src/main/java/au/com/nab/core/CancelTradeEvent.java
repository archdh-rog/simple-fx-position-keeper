package au.com.nab.core;

public class CancelTradeEvent extends AbstractTradeEvent {

    public CancelTradeEvent(long tradeId) {
        super(tradeId);
    }
}
