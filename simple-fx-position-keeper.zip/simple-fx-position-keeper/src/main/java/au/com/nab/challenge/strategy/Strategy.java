package au.com.nab.challenge.strategy;

import au.com.nab.challenge.Position;
import au.com.nab.core.Event;

import java.util.Map;

public interface Strategy {

    public Map<Long, Position> doOperation(Event event, Map<Long, Position> positionMap);
}
