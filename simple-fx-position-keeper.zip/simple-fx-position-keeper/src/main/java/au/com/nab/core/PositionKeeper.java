package au.com.nab.core;

public interface PositionKeeper {
    void processEvent(Event event);
    String printPositions();
}
